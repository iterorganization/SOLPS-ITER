#!/bin/bash
# check_catalog.sh — golden determinism + structural test for the catalog.
#
# Stage 1 (golden): snapshot catalog/out, re-run build_manifests.py,
#   build_switchsets.py, then build_catalog.py (switchsets BEFORE the
#   site — the site consumes out/switchsets.json,), diff -r.
#   PASS = manifests JSON + switchsets + static site rebuild
#   byte-identically.
# Stage 2 (structural): index table rows align with the manifest count,
#   every manifest has a page, and the ITER_2275 page carries its verdict,
#   code git hash, wall-load rows, traceability note and figure.
#
# On FAIL the catalog holds the NEW outputs; the snapshot is kept at the
# printed path for deliberate diff/restore (check_deck.sh convention).
# On PASS the snapshot and the diff scratch are removed — a green run
# leaves nothing behind (the /tmp accumulation was the old behavior).
#
# Usage: catalog/check_catalog.sh
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
# interpreter override: any Python with the reader library importable
PY="${CATALOG_PYTHON:-$HERE/../.venv/bin/python}"
OUT="$HERE/out"

SNAP_ROOT="$(mktemp -d)"
SNAP="$SNAP_ROOT/golden"
DIFF="$(mktemp -t check_catalog_diff)"
# success cleans up; a failure KEEPS both for deliberate diff/restore
trap 'rc=$?; if [ $rc -eq 0 ]; then rm -rf "$SNAP_ROOT" "$DIFF"; fi' EXIT
mkdir -p "$SNAP"
rsync -a --exclude .DS_Store "$OUT/" "$SNAP/"

if ! SOLPS_SHELL=1 "$PY" "$HERE/build_manifests.py" >/dev/null; then
  echo "FAIL: build_manifests.py exited nonzero (snapshot kept: $SNAP)"; exit 1
fi
if ! SOLPS_SHELL=1 "$PY" "$HERE/build_switchsets.py" >/dev/null; then
  echo "FAIL: build_switchsets.py exited nonzero (snapshot kept: $SNAP)"; exit 1
fi
if ! SOLPS_SHELL=1 "$PY" "$HERE/build_catalog.py" >/dev/null; then
  echo "FAIL: build_catalog.py exited nonzero (snapshot kept: $SNAP)"; exit 1
fi
if ! diff -r --exclude .DS_Store "$SNAP" "$OUT" >"$DIFF" 2>&1; then
  echo "FAIL: rebuild differs — out/ now holds NEW outputs (snapshot: $SNAP)"
  echo "diff kept at: $DIFF"
  cat "$DIFF"
  exit 1
fi
echo "PASS stage 1: manifests + switchsets + site rebuild byte-identical"

if ! SOLPS_SHELL=1 "$PY" - "$OUT" <<'EOF'
import json, re, sys
from pathlib import Path
from urllib.parse import quote

out = Path(sys.argv[1])
runs = json.loads((out / "index.json").read_text())["runs"]
idx = (out / "site" / "index.html").read_text()
runs_tbl = idx.split('<table class="runs" data-sort', 1)[1].split("</table>", 1)[0]
assert runs_tbl.count("<tr>") == len(runs) + 1, "index runs rows != manifest count"
for r in runs:
    slug = r["manifest"].removeprefix("manifests/").removesuffix(".json")
    assert (out / "site" / slug / "index.html").is_file(), f"missing page: {slug}"
run = (out / "site" / "ITER_2275_Donly_20MW__run_restart" / "index.html").read_text()
for needle in ("plateaued", "68af8ded", "181, 182", "FORMATS.md"):
    assert needle in run, f"2275 page missing: {needle}"
# the 2275 page carries its input-deck block (linked deck manifest)
assert "ITER_2275_Donly_20MW__baserun.json" in run, "2275 page missing deck marker"
assert (out / "site" / "ITER_2275_Donly_20MW__run_restart" / "wall_loads.png").is_file()
# the multi-species ITER_2171 run carries the same wall-load figure
assert (out / "site" / "ITER_2171_D+He+Be+Ne__run" / "wall_loads.png").is_file()
# one deck manifest per run family; run input_deck links resolve
families = {r["run_family"] for r in runs}
deck_files = sorted((out / "manifests").glob("*__baserun.json"))
assert len(deck_files) == len(families), \
    f"deck manifests {len(deck_files)} != run families {len(families)}"
for r in runs:
    m = json.loads((out / r["manifest"]).read_text())
    if m.get("input_deck"):
        assert (out / m["input_deck"]).is_file(), \
            f"unresolved input_deck: {r['name']} -> {m['input_deck']}"
# every classifiable run's page renders its sparkline strip —
# one inline SVG per active monitor, count == the manifest's monitors
# (JSON-driven geometry, no staged assets); the guard-skipped run carries
# the honest absence note instead — never a blank.  The convergence PNGs
# are RETIRED: no run page references convergence.png, none is staged.
n_spark = 0
for r in runs:
    m = json.loads((out / r["manifest"]).read_text())
    slug = r["manifest"].removeprefix("manifests/").removesuffix(".json")
    page = (out / "site" / slug / "index.html").read_text()
    sp = ((m.get("convergence") or {}).get("sparklines")) or {}
    if (m.get("convergence") or {}).get("verdict"):
        mons = sp.get("monitors") or {}
        assert mons, f"classifiable run without sparklines: {r['name']}"
        n_svg = page.count('<svg class="spark"')
        assert n_svg == len(mons), \
            f"{slug}: sparklines {n_svg} != manifest monitors {len(mons)}"
        assert "convergence.png" not in page, f"{slug}: retired PNG referenced"
        assert not (out / "site" / slug / "convergence.png").exists(), \
            f"{slug}: retired convergence.png still staged"
        n_spark += 1
    else:
        assert "convergence sparklines not generated" in page, f"skip note missing: {slug}"
        assert '<svg class="spark"' not in page, f"stray sparkline on skipped run: {slug}"
# the ramping_drifts page FLIPPED note -> sparkline strip when
# the guard repeal let its one 2.44 GB b2time.nc through — 9/9 strips,
# the physical span over its 100,001 records, and the classifier's
# actual verdict (evolving; an early preview said near-plateau — pinned
# is what _classify_trace computes, never the preview).
ramp = (out / "site" / "ITER_2588_drifts__ramping_drifts" / "index.html").read_text()
assert "2.5e-07 s → 2.5e-01 s over 100001 records" in ramp, \
    "ramping_drifts physical-span line missing"
assert ramp.count('<svg class="spark"') == 3, "ramping_drifts sparklines != 3"
assert ">evolving</span>" in ramp, "ramping_drifts verdict badge missing"
assert "Not assessed" not in ramp, "ramping_drifts still carries the old skip note"
assert n_spark == 9, f"sparkline strips {n_spark} != 9 (9/9 coverage)"
# the wall gate: every run page states its wall figure or exactly why there
# is none — decided from the manifest's wall_geometry JSON ONLY (the
# has_fig filesystem check retired).  A recorded figure entry
# (pass only,) must be embedded + staged; every other verdict
# renders the honest note — and NO page references a wall PNG the
# manifest does not record.
n_wallfig = n_wallnote = 0
for r in runs:
    m = json.loads((out / r["manifest"]).read_text())
    slug = r["manifest"].removeprefix("manifests/").removesuffix(".json")
    page = (out / "site" / slug / "index.html").read_text()
    if (m.get("wall_geometry") or {}).get("figure"):
        n_wallfig += 1
        assert '<img src="wall_loads.png"' in page, f"{slug}: figure not embedded"
        assert (out / "site" / slug / "wall_loads.png").is_file(), \
            f"{slug}: recorded figure not staged"
    else:
        n_wallnote += 1
        assert "wall figure not generated" in page, f"{slug}: wall note missing"
        assert '<img src="wall_loads.png"' not in page, \
            f"{slug}: unrecorded wall PNG referenced"
        assert not (out / "site" / slug / "wall_loads.png").exists(), \
            f"{slug}: unrecorded wall PNG staged"
assert n_wallfig == 2, f"wall figures {n_wallfig} != 2 (the wall gate pass set)"
assert n_wallnote == 7, f"wall notes {n_wallnote} != 7"
# every recorded diff deck has a comparison page staging the
# whole deck, and each member run page links to its family's page.
comps = json.loads((out / "index.json").read_text()).get("comparisons", [])
n_diff = 0
for c in comps:
    if not c.get("deck"):
        continue
    n_diff += 1
    fam = c["run_family"]
    cdir = out / "site" / "comparisons" / fam
    assert (cdir / "index.html").is_file(), f"missing comparison page: {fam}"
    assert (cdir / "diff_summary.txt").is_file(), f"summary not staged: {fam}"
    for name, entry in sorted(c["files"].items()):
        staged = cdir / name
        assert staged.is_file(), f"{fam}/{name}: deck file not staged"
        assert staged.stat().st_size == entry["bytes"], f"{fam}/{name}: size drift"
    for member in c["pair"]:
        slug = "__".join(member.split("/"))
        page = (out / "site" / slug / "index.html").read_text()
        # hrefs are percent-encoded with explicit index.html ('+' slugs
        # and bare directory URLs both break file:// navigation)
        assert f'href="../comparisons/{quote(fam)}/index.html"' in page, \
            f"{member}: comparison link missing"
assert n_diff == 3, f"diff decks {n_diff} != 3 (pair count)"
# the switchsets join artifact exists, declares its schema, and
# covers exactly the manifest run set (goldens untouched — the
# file is additive to out/, manifests themselves unchanged).
ss_path = out / "switchsets.json"
assert ss_path.is_file(), "out/switchsets.json missing "
ss = json.loads(ss_path.read_text())
assert ss.get("schema") == "catalog-switchsets/1", "switchsets schema key wrong"
assert set(ss["runs"]) == {r["name"] for r in runs}, \
    "switchsets run coverage != manifest run set"
# every run page carries its Switches section — the FULL
# artifact table (row count == switch_count, the Files-table
# no-truncation rule) + one pinned value per run (the b2mndr_ntim
# final, set by all 9 runs).
for r in runs:
    name = r["name"]
    slug = r["manifest"].removeprefix("manifests/").removesuffix(".json")
    page = (out / "site" / slug / "index.html").read_text()
    assert "<h2>Switches" in page, f"switches section missing: {name}"
    # the section heading links the switch index (back-link half
    # of the site linkage)
    assert 'href="../switches/index.html"' in page, f"switch index link missing: {name}"
    entry = ss["runs"][name]
    tbl = page.split('<table class="switches">', 1)[1].split("</table>", 1)[0]
    assert tbl.count("<tr>") == entry["switch_count"] + 1, \
        f"{name}: switch rows {tbl.count('<tr>')} != switch_count {entry['switch_count']} + header"
    ntim = entry["switches"]["b2mndr_ntim"]["value"]
    assert f'<td class="mono">{ntim}</td>' in tbl, \
        f"{name}: b2mndr_ntim final {ntim!r} not rendered verbatim"
    # the documented-default column — header wording + one pinned
    # default per run page (b2mndr_ntim, set by all 9 runs, default '1')
    assert '<th scope="col">documented default</th>' in tbl, \
        f"{name}: documented-default column header missing"
    d_ntim = entry["switches"]["b2mndr_ntim"]["default"]
    assert f'<td class="ddef ddef-val">{d_ntim}</td>' in tbl, \
        f"{name}: b2mndr_ntim documented default {d_ntim!r} not rendered"
# the switch index page (switch -> runs) — one row per
# inverted_index key (rows carry anchor ids, so they are counted as
# '<tr id="' plus exactly one bare thead '<tr>' header), and both
# linkage needles.
sw_page_path = out / "site" / "switches" / "index.html"
assert sw_page_path.is_file(), "switch index page missing "
sw_page = sw_page_path.read_text()
n_sw = len(ss["inverted_index"])
sw_tbl = sw_page.split('<table class="switches" data-sort data-filter>', 1)[1].split("</table>", 1)[0]
assert sw_tbl.count('<tr id="') == n_sw, \
    f"switch index id-rows {sw_tbl.count('<tr id=')} != {n_sw} keys"
assert sw_tbl.count("<tr>") == 1, "switch index thead header rows != 1"
assert f'<tr id="b2tfnb_drift_style">' in sw_tbl, "anchor row missing"
# one pinned default per index row kind — the prose golden on
# b2tfnb_drift_style + the numeric b2mndr_ntim default, each ONCE per row
assert "documented default See description" in sw_tbl, \
    "switch index prose default missing (b2tfnb_drift_style)"
ntim_line = [l for l in sw_tbl.split("\n") if l.startswith('<tr id="b2mndr_ntim">')]
assert ntim_line and "documented default 1</span>" in ntim_line[0], \
    "switch index b2mndr_ntim documented default missing"
assert 'href="switches/index.html"' in idx, "catalog index missing switch link"
# + release report pages — one per committed page-data
# join under out/deltarun_pages/ (the site never reads the gitignored
# cache); the GOLDEN pair's page carries the ITER_2275 md5s verbatim
# (inside the collapsed audit — full hashes live ONLY there), every
# recorded A/B deck is staged + size-verified against the # inventory, and the catalog index links each page.  triage
# metrics: the publish-commit verdict line VERBATIM, <=3 top-level
# sections before the first collapsed disclosure block, all blocks
# collapsed by default (no 'open'), and no full 32/40-hex hash outside
# the audit (12-char prefixes + ellipsis everywhere else).
rp_paths = sorted((out / "deltarun_pages").glob("*.json"))
assert rp_paths, "no release page-data joins under out/deltarun_pages/"
n_relpg = n_reldeck = n_relwall = 0
gpage_needles = []   # one-sided honesty needles, filled per join
for rp_path in rp_paths:
    rp = json.loads(rp_path.read_text())
    assert rp.get("schema") == "catalog-deltarun-page/2", \
        f"{rp_path.name}: wrong page-data schema"
    pdir = out / "site" / "deltarun" / rp_path.stem
    assert (pdir / "index.html").is_file(), \
        f"missing release page: {rp_path.stem}"
    n_relpg += 1
    for c in rp.get("cases") or []:
        # every recorded wall figure is staged + size-verified,
        # and the one-sided note + driver command render on the page.
        # (BEFORE the deck 'continue' — deck-less cases carry walls.)
        wfig = (c.get("wall") or {}).get("figure")
        if wfig:
            n_relwall += 1
            staged = pdir / wfig["path"].split("/")[-1]
            assert staged.is_file(), \
                f"{rp_path.stem}/{wfig['path']}: not staged"
            assert staged.stat().st_size == wfig["bytes"], \
                f"{rp_path.stem}/{wfig['path']}: staged size drift"
            one = [r.get("one_sided") for r in (c["wall"].get("runs") or [])
                   if r.get("one_sided")]
            if one:
                gpage_needles.append((rp_path.stem, one[0]["note"],
                                      one[0]["driver_command"]))
        deck = (c.get("decks") or {}).get("deck")
        if not deck:
            continue
        n_reldeck += 1
        ddir = pdir / deck["deck"].split("/")[-1]
        for name, entry in sorted((deck.get("files") or {}).items()):
            staged = ddir / name
            assert staged.is_file(), f"{rp_path.stem}/{name}: not staged"
            assert staged.stat().st_size == entry["bytes"], \
                f"{rp_path.stem}/{name}: staged size drift"
gold_rp = (out / "site" / "deltarun" / "79bb46bc_ab87f750" / "index.html")
assert gold_rp.is_file(), "golden release report page missing"
gpage = gold_rp.read_text()
assert "b539b7a5035f05f9534b56680b167cb5" in gpage and \
    "cc6ecaabc5f7bd92fac59d50677deb5d" in gpage, \
    "golden release page missing the ITER_2275 md5 pair (both sides)"
assert gpage.split("<details", 1)[0].count("<h2>") <= 3, \
    "golden release page: >3 top-level sections before the audit"
assert "<details open" not in gpage, "audit not collapsed by default"
assert rp_paths and all(
    json.loads(p.read_text(encoding="utf-8")).get("publish_subject")
    for p in rp_paths), "every release JSON must carry a publish_subject"
# the golden pair's own page — keyed by its FIXED stem, not by which
# path happens to sort first (a future '0a…' stem must not silently
# re-point this assertion at the wrong release)
_golden_rp = next(
    (p for p in rp_paths if p.name.startswith("79bb46bc_ab87f750")),
    None)
assert _golden_rp is not None, "golden release JSON 79bb46bc missing"
assert json.loads(
    _golden_rp.read_text(encoding="utf-8"))["publish_subject"] in gpage, \
    "golden release page missing the publish-commit verdict line"
for stem, note, cmd in gpage_needles:      # (golden pair only)
    if stem != "79bb46bc_ab87f750":
        continue
    assert note in gpage, \
        f"{stem}: wall one-sided note not rendered verbatim"
    assert cmd in gpage, f"{stem}: wall driver command not rendered"
outside = re.sub(r'href="[^"]*"', "",
                 " ".join(re.split(r"<details.*?</details>", gpage, flags=re.S)))
assert not re.findall(r"[0-9a-f]{32,}", outside), \
    "full hash rendered outside the audit (12-char prefixes only)"
assert '<h2><span class="sn">03</span>Release reports</h2>' in idx, \
    "catalog index missing release section"
assert 'href="deltarun/79bb46bc_ab87f750/index.html"' in idx, \
    "catalog index missing the golden release page link"
# the version-axis index — the pinned resolver axis (all three
# versions + their 12-char commit prefixes), every built pair with its
# verdict line, unbuilt pairs as honest cells carrying the EXACT driver
# command for copy, and the golden report page's audit renders the
# driver's Selection & budget block (the join's `selection` key).
axis_path = out / "site" / "deltarun" / "index.html"
assert axis_path.is_file(), "version-axis index page missing "
axis = axis_path.read_text()
for needle in ("3.0.8", "3.0.9", "3.0.10",
               "e0e580b56203", "753cbdf2b069", "ab87f75097b1"):
    assert needle in axis, f"version-axis page missing {needle}"
n_axis_cmd = axis.count("bin/python build_release_report.py")
assert n_axis_cmd == 3, \
    f"version-axis unbuilt command cells {n_axis_cmd} != 3 (all pairs unbuilt)"
assert "build_release_report.py 3.0.9 3.0.10" in axis, "driver command missing"
assert 'href="79bb46bc_ab87f750/index.html"' in axis, \
    "version-axis page missing the built golden report link"
assert "off the pinned axis" in axis, "raw-sha honest section missing"
assert 'href="deltarun/index.html"' in idx, \
    "catalog index missing the version-axis link"
assert "Selection &amp; budget (driver)" in gpage, \
    "golden report page missing the driver selection audit block"
gold_join = json.loads((out / "deltarun_pages" / "79bb46bc_ab87f750.json")
                       .read_text())
assert gold_join["selection"]["command"] in gpage, \
    "golden report page selection block not rendered verbatim"
# case-centric release history — one screen per tarball in the
# union of the committed joins' md5 tables (27 on the golden join),
# every catalog run page cross-links its family tarball's screen (the
# pinned mapping run_family + ".tar.gz"; %2B slugs), the GOLDEN screen
# carries the ITER_2275 flip as 12-char prefixes + the one-sided
# analysis fact + its stability verdict, the never-changed tarball
# carries its own verdict, and full hashes stay inside the audit.
hist_names = set()
for rp_path in rp_paths:
    for t in json.loads(rp_path.read_text()).get("tarballs") or []:
        hist_names.add(t["name"])
assert hist_names, "no tarballs across the joins "
n_casepg = 0
for name in sorted(hist_names):
    spath = (out / "site" / "deltarun" / "cases"
             / name.removesuffix(".tar.gz") / "index.html")
    assert spath.is_file(), f"missing case screen: {name}"
    n_casepg += 1
assert n_casepg == 27, f"case screens {n_casepg} != 27 (the golden set)"
gold_case = (out / "site" / "deltarun" / "cases"
             / "ITER_2275_Donly_20MW" / "index.html").read_text()
assert "b539b7a5035f…" in gold_case and "cc6ecaabc5f7…" in gold_case, \
    "ITER_2275 case screen missing the golden-pair md5 flip (prefixes)"
assert "b539b7a5035f05f9534b56680b167cb5" in gold_case and \
    "cc6ecaabc5f7bd92fac59d50677deb5d" in gold_case, \
    "ITER_2275 case screen missing the full md5s (audit block)"
assert "stats are new-side-only" in gold_case, \
    "ITER_2275 case screen missing the one-sided analysis fact"
assert "changes most releases" in gold_case, \
    "ITER_2275 case screen missing its stability verdict"
assert 'href="../../79bb46bc_ab87f750/index.html"' in gold_case, \
    "case screen not linking its pair report"
outside_case = re.sub(r'href="[^"]*"', "",
                      " ".join(re.split(r"<details.*?</details>",
                                        gold_case, flags=re.S)))
assert not re.findall(r"[0-9a-f]{32,}", outside_case), \
    "case screen: full hash rendered outside the audit"
stable_case = (out / "site" / "deltarun" / "cases"
               / "tutorial-DivGeo_ITER_baseline_scenario"
               / "index.html").read_text()
assert "unchanged since" in stable_case, \
    "never-changed tarball missing its stability verdict"
for r in runs:
    slug = r["manifest"].removeprefix("manifests/").removesuffix(".json")
    page = (out / "site" / slug / "index.html").read_text()
    fam = r.get("run_family") or r["machine"]
    if f"{fam}.tar.gz" in hist_names:
        assert (f'href="../deltarun/cases/{quote(fam)}/index.html"'
                in page), f"{slug}: release-history link missing"
    else:
        assert "no built pair covers this tarball" in page, \
            f"{slug}: honest release-history note missing"
assert "<h2>Case histories (27)</h2>" in axis, \
    "version-axis page missing the Case histories section"
assert 'href="cases/ITER_2275_Donly_20MW/index.html"' in axis, \
    "version-axis page missing a case screen link"
print(f"structural OK: {len(runs)} manifests, pages aligned, 2275 markers present, "
      f"{len(deck_files)} deck manifests linked, {n_wallfig} wall figures + "
      f"{n_wallnote} wall notes, {n_spark} sparkline strips, "
      f"{n_diff} comparison decks, switchsets for {len(ss['runs'])} runs, "
      f"switches sections on {len(runs)} run pages, switch index {n_sw} rows, "
      f"{n_relpg} release report pages ({n_reldeck} staged pair decks, "
      f"{n_relwall} wall figures), "
      f"version-axis index ({n_axis_cmd} build commands), "
      f"{n_casepg} case history screens")
EOF
then
  echo "FAIL: structural QC failed"
  exit 1
fi

echo "PASS: catalog golden + structural"
