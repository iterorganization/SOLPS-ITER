#!/usr/bin/env python3
"""Run-manifest generator over the Zenodo example runs (catalog v0, step #2).

Walks SOLPS-ITER/runs/examples, finds directories that carry solver outputs
(fort.44 / b2fstate / b2time.nc), and emits one JSON manifest per run dir
plus a top-level index.json — the shared JSON layer for the static catalog
 and the MCP tools .

Manifest = pillar-1 provenance, lite:
  identity + code versions (the git hashes the fort files stamp and no
  official tool consumes) + grid/species + convergence verdict (reuses
  SOLPS-Reader's _classify_trace — parity with the run-convergence MCP tool) +
  key-file inventory with MD5s + wall-load summary.

Deterministic: sorted walks, sort_keys JSON, no timestamps, no mtimes.
MD5 only for files <= 200 MB (size recorded for all); b2time.nc convergence
skipped above 3 GiB (pure-python reader cost, the fixed size threshold).

each run family also ships its sibling INPUT DECK (<family>/
baserun) as one deck manifest out/manifests/<family>__baserun.json, and
every run manifest links to it via `input_deck` (nullable). The linkage
is STRUCTURAL (sibling-directory convention, runs/Makefile:131 vpath) —
not content-verified provenance; runs may override deck inputs locally
(FORMATS.md "Input-deck linkage" honesty rule).

per-run `artifacts` block is RETIRED (, 2026-09-29):
its only payload was the convergence trace figures, whose evidence role
moved into the convergence block's `sparklines` (one inline SVG per
active monitor on the run pages — no staged PNGs, no figure generator;
make_convergence_figure.py and figures/*__convergence.png are deleted).
Run manifests carry no `artifacts` key at all now; the family diff
decks below remain the family-scope artifact inventory.

index.json gains a `comparisons` array — the same artifacts
doctrine at FAMILY scope.  Per family, the canonical diff pair
(family_diff_pairs below, single-sourced for build_diff_decks.py) and the
state-diff deck it owns under figures/<family>__diff/ are inventoried
(path + size + MD5 per file); families without a deck record an honest
skip.  Run build_diff_decks.py BEFORE this script too.

ConvSpark the convergence block gains an additive `sparklines`
key — the physical time span (timesa first/last) plus one downsampled
series per ACTIVE monitor (keys exactly `active_verdicts`; fixed ruling:
b2time.nc is read only for those named monitors' values and the span,
never to re-derive verdicts or the active set).  A run directory found
without b2time.nc is a HARD error, not an honest absence.

ConvSpark repealed the v0 500 MB guard for exactly one file,
ITER_2588_drifts/ramping_drifts/b2time.nc, via a one-entry
CONV_GUARD_ALLOWLIST (measured full-read cost: 88 s cold / 2.9 s warm,
~4.7 GiB peak RSS).  AutoIngest (2026-09-29) RETIRED that
allowlist and replaced the whole mechanism with the fixed 3 GiB
threshold (CONV_MAX_BYTES below): the 2.28 GiB ramping_drifts file —
and any new run's big-but-sane monitor file — reads automatically, no
per-file edit ever again; only a >3 GiB file skips (reader floor
~6.4 GiB RAM, FORMATS.md section).

AutoIngest the wall gate (2026-09-29): every run manifest gains a
`wall_geometry` block — the gate-driven outcome of matching the run's
own wlareas against the six block-3a surfaces recomputed from the
family baserun fort.30 (wall_gate_outcome / wall_geometry_block below;
build_wall_figure.py imports the same gate, so the figure RUN set is
DERIVED, not tabulated).  Verdicts: pass | fail | unsupported |
unreadable | no-wall-data; the figure artifact entry (path + size +
MD5, pattern) appears ONLY on pass — a pass without its figure
is a hard error, and only a pass may paint .

Run with the SOLPS-Reader venv interpreter (house rule).
"""
from __future__ import annotations

import hashlib
import json
import sys
from itertools import combinations
from pathlib import Path

import numpy as np

from solps_reader.ft44 import read_ft44
from solps_reader.ft46 import read_header as ft46_read_header
from solps_reader.nc import load_nc
from solps_reader.cli import _classify_trace
from solps_reader.state import read_b2fstate

from f30_mesh import (
    ITER_MESH_DIMS, ITER_SURFACES, block3a_wlareas, read_fort30,
    surface_area, torus_factor,
)

HERE = Path(__file__).resolve().parent
EXAMPLES = HERE.parents[1] / "SOLPS-ITER" / "runs" / "examples"
OUT = HERE / "out"
FIGURES_DIR = HERE / "figures"

MARKERS = ("fort.44", "b2fstate", "b2time.nc")
KEY_FILES = (
    "fort.44", "fort.46", "b2fstate", "b2time.nc", "b2fplasma",
    "b2fmovie", "b2mn.dat", "b2fgmtry",
)
MD5_MAX_BYTES = 200 * 1024 * 1024
CONV_MAX_BYTES = 3 * 1024**3
#: (2026-09-29): the b2time.nc convergence-read size guard —
#: 3 GiB BINARY (3 * 1024**3 = 3,221,225,472 B; the same MiB/GiB
#: convention as MD5_MAX_BYTES above), decided on stat().st_size ALONE
#: so the skip is deterministic on any machine (never free RAM / load
#: — a machine-dependent skip would break the byte-identical proof).
#: Sized from the measured reader cost: load_nc peaks at ~2x file size
#: RSS (the 2.28 GiB ramping_drifts b2time.nc measured 4.7 GiB peak),
#: so a just-under-threshold file needs ~6.4 GiB free at build time —
#: the documented hardware floor.  Retires the v0 500 MB guard AND the
#: one-file allowlist in the same act; a >3 GiB file skips
#: with the reason string in convergence_block below.
CLASSES = ("plateaued", "near-plateau", "evolving", "constant")
DECK_DIR = "baserun"
DECK_NOTE = (
    "sibling input deck of the family's run dirs (runs/Makefile:131 vpath "
    "search path); run markers absent below — that absence is what makes "
    "this a deck, not a run"
)


def md5_of(path: Path) -> str | None:
    if path.stat().st_size > MD5_MAX_BYTES:
        return None
    h = hashlib.md5()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def file_entry(path: Path) -> dict:
    return {"bytes": path.stat().st_size, "md5": md5_of(path)}


def find_run_dirs(root: Path) -> list[Path]:
    found = []
    for d in sorted(p for p in root.rglob("*") if p.is_dir()):
        if any((d / m).exists() for m in MARKERS):
            found.append(d)
    return found


def fort46_provenance(path: Path) -> dict | None:
    try:
        with open(path, encoding="ascii") as fh:
            h = ft46_read_header(fh)
    except Exception:
        return None
    return {
        "version": h.version, "git_hash": h.git_hash, "ntri": h.ntri,
        "species": h.species,
    }


#: sparkline budget: stride = max(1, n // 40) over the classifier's
#: record window — the FULL 1-D trace `_classify_trace` ravels (SOLPS-Reader
#: src/SOLPS-Reader/cli.py:579-593; the same arrays convergence_block passes it
#: below), with the final record ALWAYS included.  pinned edges:
#: 700 records -> stride 17 (43 kept), 11 records -> stride 1 (all points).
SPARK_STRIDE_TARGET = 40


def spark_series(values: np.ndarray) -> list[float]:
    """Downsample one full record trace to the sparkline series.

    Pure index selection, never arithmetic: each kept value is the
    verbatim tally at that record (json repr round-trip downstream), so
    the series re-derives from the file bytes alone.
    """
    n = int(np.asarray(values).size)
    stride = max(1, n // SPARK_STRIDE_TARGET)
    keep = list(range(0, n, stride))
    if keep[-1] != n - 1:
        keep.append(n - 1)
    return [float(values[i]) for i in keep]


def convergence_block(path: Path) -> dict:
    """One b2time.nc -> the convergence + sparklines block.

    A file over CONV_MAX_BYTES (decision on st_size alone, BEFORE any
    read) keeps its honest skip; everything at or under gets the full
    single-source read — no allowlist exists since retired it.
    """
    if path.stat().st_size > CONV_MAX_BYTES:
        return {"skipped": f"b2time.nc > {CONV_MAX_BYTES // (1 << 30)} GB "
                           "(reader floor ~6.4 GiB RAM)"}
    try:
        ncf = load_nc(path)
        names = [n for n in ncf.time_traces() if ncf.variable(n).data.size > 0]
        classes = {n: _classify_trace(np.asarray(ncf.variable(n).data)) for n in names}
    except Exception as exc:  # unreadable NC -> honest null, not a crash
        return {"error": f"{type(exc).__name__}: {exc}"}
    counts = {c: sum(1 for v in classes.values() if v == c) for c in CLASSES}
    # Verdict over ACTIVE monitors only — parity with the run-convergence
    # MCP tool: time bases (strictly increasing, e.g. timesa) evolve by
    # design and constant-zero traces were never computed; neither counts.
    time_bases = [n for n in names
                  if bool(np.all(np.diff(np.asarray(ncf.variable(n).data, dtype=float)) > 0))]
    active = [n for n in names
              if n not in time_bases and classes[n] != "constant"]
    if not active:
        verdict = "static"
    elif any(classes[n] == "evolving" for n in active):
        verdict = "evolving"
    elif any(classes[n] == "near-plateau" for n in active):
        verdict = "near-plateau"
    else:
        verdict = "plateaued"
    # physical span + per-active-monitor series, same record
    # window the classifier read (the full arrays above).  A readable
    # b2time.nc without `timesa` is a schema surprise — the KeyError is
    # deliberately loud here (no honest-null path for a missing span).
    timesa = np.asarray(ncf.variable("timesa").data, dtype=float)
    monitors = {
        n: {"units": ncf.variable(n).units or "",
            "values": spark_series(np.asarray(ncf.variable(n).data))}
        for n in active
    }
    return {"verdict": verdict, "counts": counts, "nrecords": ncf.num_records,
            "ntraces": len(names), "n_active": len(active),
            "time_bases": time_bases,
            "active_verdicts": {n: classes[n] for n in active},
            "sparklines": {
                "time_span_s": {"start": float(timesa[0]),
                                "end": float(timesa[-1])},
                "monitors": monitors,
            }}


#: SI labels for the integrated wall tallies — catalog/FORMATS.md unit
#: table (solps.tex "Output files" :5064-5067; audit 2026-09-24).
#: The per-element wld* tallies ARE SI rates/powers — there are no
#: conversion factors to apply.  The channels differ in direction, which
#: the labels must keep visible: ion impinges, atom/mol/eb are net-emitted.
WALL_SI = {
    "ion": ("particles s-1", "impinging plasma-ion flux (wldpp)"),
    "atom": ("particles s-1", "net-emitted atom flux (wldpa)"),
    "mol": ("particles s-1", "net-emitted molecule flux (wldpm)"),
    "eb": ("W", "power of emitted particles (wldpeb)"),
}
WALL_UNITS_NOTE = (
    "per-element SI rates/powers (solps.tex :5064-5067, catalog/FORMATS.md): "
    "wldpp/wldpa/wldpm particles s-1 (ion impinging; atom/mol net-emitted), "
    "wldpeb W"
)


def wall_summary(w) -> dict | None:
    if w is None:
        return None
    nw = w.nlim + w.nsts

    def rowvec(field):
        # Stratum-0 (total-over-strata) per-element vector; species summed.
        if field is None:
            return np.zeros(nw)
        return field[..., 0].sum(axis=1) if field.ndim == 3 else field[:, 0]

    def total(field):
        return float(rowvec(field).sum())

    ion, atom, mol = rowvec(w.wldpp), rowvec(w.wldpa), rowvec(w.wldpm)
    eb = rowvec(w.wldpeb)
    p_tot = ion + atom + mol + eb       # nonzero-detector (mixes units by design)
    part = ion + atom + mol             # the s-1 channels alone (SI-coherent)
    raw = {
        "ion": total(w.wldpp), "atom": total(w.wldpa),
        "mol": total(w.wldpm), "eb": total(w.wldpeb),
    }
    loaded = []
    for i in np.nonzero(p_tot)[0]:
        area = float(w.wlarea[i]) if w.wlarea is not None else 0.0
        loaded.append({
            "row": int(i),
            "isrftype": int(w.isrftype[i]) if w.isrftype is not None else None,
            "area_m2": area or None,
            "particle_flux_s1": float(part[i]),
            "particle_flux_density_m2_s1":
                float(part[i] / area) if area > 0 else None,
            "emitted_power_w": float(eb[i]),
        })
    return {
        "nlim": w.nlim, "nsts": w.nsts, "nstra": w.nstra,
        "loaded_rows": [e["row"] for e in loaded],
        "polygon_segments_nonzero": int((p_tot[: w.nlim] > 0).sum()),
        "integrated_raw": raw,
        "integrated_si": {
            k: {"value": raw[k], "unit": unit, "what": what}
            for k, (unit, what) in WALL_SI.items()
        },
        "loaded_rows_si": loaded,
        "units": WALL_UNITS_NOTE,
    }


#: the wall gate (2026-09-29): the wall-geometry gate.  Every run carrying a
#: fort.44 wall section is gate-attempted automatically: the six
#: block-3a surfaces are recomputed from the family baserun fort.30
#: (f30_mesh.py; tests/test_f30_gate.py is the pinned authority) and
#: compared to the run's OWN wlareas over the card window
#: (f30_mesh.block3a_wlareas — the alignment helper; a naive zip against
#: loaded_rows_si misaligns by one card and false-FAILs at ~19x).
#: Only a PASS may paint (never paint unverified geometry);
#: every other outcome is recorded, never a crash and never a guess.
#: Non-ITER meshes are RECORDED OUTCOMES, not exceptions.
WALL_GATE_TOL = 5e-6   # == tests/test_f30_gate.py TOL (pinned authority)


def wall_gate_outcome(run_dir: Path, wall) -> dict:
    """Gate one run's wall geometry -> outcome dict (no figure inventory).

    Verdicts: ``pass`` (all six areas agree within WALL_GATE_TOL — the
    only painter's license), ``fail`` (readable, supported shape, areas
    disagree), ``unsupported`` (mesh readable but not the ITER 90x36
    family ITER_SURFACES was verified on, or the wall topology is not
    the six-card block), ``unreadable`` (read_fort30 raised — caught
    per-family and recorded), ``no-wall-data`` (nothing to gate).
    """
    if wall is None:
        return {"verdict": "no-wall-data",
                "note": "no fort.44 wall-load section among this run's outputs"}
    rel = run_dir.relative_to(EXAMPLES)
    mesh_rel = f"{rel.parts[0]}/{DECK_DIR}/fort.30"
    try:
        xpol, ypol, npoint, dimxh, dimyh = read_fort30(EXAMPLES / mesh_rel)
    except Exception as exc:  # unreadable mesh is data, not a crash
        # relativize the path read_fort30 embeds so the recorded error
        # stays machine-independent (byte-identical rebuild proof)
        msg = str(exc).replace(f"{EXAMPLES}/", "")
        return {"verdict": "unreadable", "mesh": mesh_rel,
                "error": f"{type(exc).__name__}: {msg}"}
    block: dict = {
        "mesh": mesh_rel,
        "dims": [dimxh, dimyh],
        "patch": [list(p) for p in npoint],
    }
    if (dimxh, dimyh) != ITER_MESH_DIMS:
        return {**block, "verdict": "unsupported",
                "reason": f"mesh dims {(dimxh, dimyh)} != {ITER_MESH_DIMS} "
                          "(dimxh, dimyh) — ITER_SURFACES windows are "
                          "verified for the ITER 90x36 family only"}
    try:
        wlareas = block3a_wlareas(wall)
    except ValueError as exc:
        return {**block, "verdict": "unsupported", "reason": str(exc)}
    factor = torus_factor()
    surfaces = []
    for (name, idimp, inump, a, b), gold in zip(ITER_SURFACES, wlareas):
        got = surface_area(xpol, ypol, idimp, inump, a, b, factor)
        # a zero wlarea block divides nothing: an exact zero matches,
        # anything else is an unbounded miss (recorded, never a crash)
        rel = (abs(got - gold) / gold if gold
               else (0.0 if got == gold else float("inf")))
        surfaces.append({"surface": name, "computed_m2": got,
                         "wlarea_m2": gold, "rel": rel})
    worst = max(s["rel"] for s in surfaces)
    block.update({
        "surfaces": surfaces,
        "worst_rel": worst,
        "tol": WALL_GATE_TOL,
        "verdict": "pass" if worst <= WALL_GATE_TOL else "fail",
    })
    return block


def wall_geometry_block(run_dir: Path, wall) -> dict:
    """The manifest's wall_geometry block: the gate outcome plus — on
    pass ONLY — the figure artifact entry (pattern: hash-pinned
    like a key file, so the site renders figure-or-note from JSON)."""
    block = wall_gate_outcome(run_dir, wall)
    if block["verdict"] != "pass":
        return block
    slug = "__".join(run_dir.relative_to(EXAMPLES).parts)
    fig = FIGURES_DIR / f"{slug}.png"
    if not fig.is_file():
        # Build-order invariant (figures -> manifests -> site): a PASS
        # without its figure is an ingest bug wearing an honest-absence
        # mask — loud, same ruling as the missing-b2time.nc error.
        raise FileNotFoundError(
            f"{run_dir.relative_to(EXAMPLES)}: gate PASS but {fig} missing "
            "— run build_wall_figure.py before build_manifests.py")
    block["figure"] = {"path": f"figures/{slug}.png", **file_entry(fig)}
    return block


def deck_manifest(family: str, deck_dir: Path) -> dict:
    """Inventory one family's sibling input deck (<family>/baserun).

    A deck is defined by marker ABSENCE: no fort.44 / b2fstate / b2time.nc
    (the same MARKERS find_run_dirs uses), hence no convergence / fort44 /
    fort46 blocks here. Full recursive file inventory, sizes for all, MD5
    under the same 200 MB rule; .DS_Store (Finder metadata, not deck
    content) is skipped so the manifest stays stable under browsing.
    """
    files: dict[str, dict] = {}
    for p in sorted(deck_dir.rglob("*")):
        if not p.is_file() or p.name == ".DS_Store":
            continue
        rel = p.relative_to(deck_dir).as_posix()
        files[rel] = file_entry(p)
    return {
        "name": f"{family}/{DECK_DIR}",
        "kind": "input_deck",
        "machine": family.split("_")[0],
        "run_family": family,
        "files": files,
        "file_count": len(files),
        "total_bytes": sum(e["bytes"] for e in files.values()),
        "geometry": files.get("b2fgmtry"),
        "run_markers": {m: (deck_dir / m).exists() for m in MARKERS},
        "note": DECK_NOTE,
    }


def family_diff_pairs(
    root: Path,
) -> list[tuple[str, list[str] | None, int, list[tuple[str, str]]]]:
    """canonical diff-pair rule, single-sourced here (the deck
    generator build_diff_decks.py imports it — one rule, two consumers).

    Within each family, members are sorted lexicographically and the deck
    pair is the FIRST TWO whose b2fstate pass SOLPS-Reader ``state diff``'s
    precondition: equal guard-box ``grid_shape`` AND equal species
    signature ``[(zamin, zamax, zn, am)]`` — exactly the two checks
    ``_diff_precheck`` runs (cli.py:679, :689-691); version/git
    differences are provenance NOTEs there, not gates.  Families whose
    no member pair passes are an honest skip (single-member families in
    this catalog).

    A member whose b2fstate cannot be READ (corrupt, foreign format) is
    a NAMED failure, never a silent absence: it rides the fourth slot as
    (member, reason) and surfaces in the manifest's skip note — a family
    must not under-count its members because one of them is broken.

    Returns [(family, pair_or_None, n_members_with_b2fstate,
    [(member, reason)])] over every family that has at least one
    b2fstate-bearing or failed member, sorted by family.
    """
    families: dict[str, list[tuple[str, tuple]]] = {}
    failures: dict[str, list[tuple[str, str]]] = {}
    for run_dir in find_run_dirs(root):
        name = str(run_dir.relative_to(root))
        st_file = run_dir / "b2fstate"
        if not st_file.is_file():
            continue
        try:
            st = read_b2fstate(st_file)
            sig = (tuple(st.grid_shape),
                   tuple((sp.zamin, sp.zamax, sp.zn, sp.am) for sp in st.species))
        except Exception as exc:
            failures.setdefault(name.split("/")[0], []).append(
                (name, f"{type(exc).__name__}: {exc}"))
            continue
        families.setdefault(name.split("/")[0], []).append((name, sig))
    out = []
    for family in sorted(set(families) | set(failures)):
        members = sorted(families.get(family, []))
        pair = next(
            ([na, nb] for (na, sa), (nb, sb) in combinations(members, 2)
             if sa == sb),
            None,
       )
        out.append((family, pair, len(members), failures.get(family, [])))
    return out


#: What a diff-deck entry claims about itself (the site renders this note;
#: the honest wording matters — the deck is a STAGED ARTIFACT generated by
#: build_diff_decks.py through the SOLPS-Reader CLI, never recomputed).
DIFF_DECK_NOTE = (
    "SOLPS-Reader state diff deck (A -> B): one overlay+difference PNG per "
    "catalog field plus diff_summary.txt, generated by build_diff_decks.py "
    "through the SOLPS-Reader CLI; staged artifact, "
    "hash-pinned here like a key file, never recomputed by the site"
)


def comparisons_block(root: Path) -> list[dict]:
    """the family-level artifacts inventory for index.json.

    One entry per run family: the canonical pair (family_diff_pairs) and,
    when the deck exists under figures/<family>__diff/, its full file
    inventory (same 200 MB MD5 rule as run files), figure count, summary
    line count and the field order the CLI's summary itself lists (the
    catalog order te, ti, ne, na_k..., po — NOT filename order; na_10
    sorts between na_1 and na_2 lexicographically).  Families without a
    deck record an honest skip — no pair, or the generator has not run.
    """
    entries = []
    for family, pair, n_members, failures in family_diff_pairs(root):
        entry: dict = {"run_family": family, "pair": pair, "deck": None}
        if failures:
            entry["unreadable_members"] = [
                {"run": m, "reason": r} for m, r in failures]
        if pair is None:
            fail_note = ("; unreadable: " + ", ".join(
                f"{m} ({r})" for m, r in failures)) if failures else ""
            entry["skipped"] = (
                f"{n_members} member(s) with b2fstate, no pair passes the "
                "same-grid + same-species diff precondition"
                + fail_note
           )
            entries.append(entry)
            continue
        deck_dir = FIGURES_DIR / f"{family}__diff"
        summary = deck_dir / "diff_summary.txt"
        if not summary.is_file():
            entry["skipped"] = (
                "deck not generated — run build_diff_decks.py before "
                "build_manifests.py"
           )
            entries.append(entry)
            continue
        files = {p.name: file_entry(p) for p in sorted(deck_dir.iterdir())
                 if p.is_file()}
        lines = summary.read_text(encoding="utf-8").splitlines()
        fields = next((ln.split()[1:] for ln in lines
                       if ln.startswith("fields")), None)
        entry.update({
            "deck": f"figures/{family}__diff",
            "files": files,
            "n_figures": sum(1 for n in files if n.endswith(".png")),
            "summary_lines": len(lines),
            "fields": fields,
            "note": DIFF_DECK_NOTE,
        })
        entries.append(entry)
    return entries


def build_manifest(run_dir: Path, root: Path) -> dict:
    rel = run_dir.relative_to(root)
    deck_slug = f"manifests/{rel.parts[0]}__{DECK_DIR}.json"
    m: dict = {
        "name": str(rel),
        "machine": rel.parts[0].split("_")[0],   # ITER / AUG / MAST
        "run_family": rel.parts[0],
        # Structural linkage only (FORMATS.md honesty rule): the sibling
        # baserun exists; nothing here verifies the run started from it.
        "input_deck": deck_slug if (run_dir.parent / DECK_DIR).is_dir() else None,
        "files": {n: file_entry(run_dir / n) for n in KEY_FILES
                  if (run_dir / n).exists()},
    }
    f44 = run_dir / "fort.44"
    ft = None
    if f44.exists():
        try:
            ft = read_ft44(f44)
            h = ft.header
            m["fort44"] = {
                "version": h.version, "git_hash": h.git_hash,
                "grid": {"nx": h.nx, "ny": h.ny},
                "species": h.species,
            }
            m["wall"] = wall_summary(ft.wall)
        except Exception as exc:
            m["fort44"] = {"error": f"{type(exc).__name__}: {exc}"}
    # the wall gate: gate outcome on EVERY run (an honest note is information
    # too).  Outside the fort.44 read try so the pass-without-figure hard
    # error in wall_geometry_block is not masked into a fort44 error block.
    m["wall_geometry"] = wall_geometry_block(
        run_dir, None if ft is None else ft.wall)
    f46 = run_dir / "fort.46"
    if f46.exists():
        m["fort46"] = fort46_provenance(f46)
    bt = run_dir / "b2time.nc"
    if not bt.is_file():
        # b2time.nc is the convergence + sparklines source.  A run
        # found by fort.44/b2fstate alone would silently read as a verdict
        # skip in the index — an ingest bug wearing an honest-absence mask.
        raise FileNotFoundError(
            f"{rel}: no b2time.nc — convergence/sparklines cannot be built")
    m["convergence"] = convergence_block(bt)
    return m


def main() -> None:
    runs = find_run_dirs(EXAMPLES)
    manifests_dir = OUT / "manifests"
    manifests_dir.mkdir(parents=True, exist_ok=True)

    index = []
    wg_counts: dict[str, int] = {}
    for run_dir in runs:
        m = build_manifest(run_dir, EXAMPLES)
        v = m["wall_geometry"]["verdict"]
        wg_counts[v] = wg_counts.get(v, 0) + 1
        slug = "__".join(m["name"].split("/"))
        (manifests_dir / f"{slug}.json").write_text(
            json.dumps(m, indent=2, sort_keys=True) + "\n"
       , encoding="utf-8")
        index.append({
            "name": m["name"], "machine": m["machine"],
            "run_family": m.get("run_family", m["machine"]),
            "verdict": (m.get("convergence") or {}).get("verdict"),
            "grid": (m.get("fort44") or {}).get("grid"),
            "species": (m.get("fort44") or {}).get("species"),
            "code_git": (m.get("fort44") or {}).get("git_hash"),
            "has_wall_loads": bool((m.get("wall") or {}).get("loaded_rows")),
            "manifest": f"manifests/{slug}.json",
        })

    # one deck manifest per run family that carries a baserun.
    decks = []
    for family in sorted({r["name"].split("/")[0] for r in index}):
        deck_dir = EXAMPLES / family / DECK_DIR
        if not deck_dir.is_dir():
            continue
        dm = deck_manifest(family, deck_dir)
        (manifests_dir / f"{family}__{DECK_DIR}.json").write_text(
            json.dumps(dm, indent=2, sort_keys=True) + "\n"
       , encoding="utf-8")
        decks.append({
            "run_family": family,
            "manifest": f"manifests/{family}__{DECK_DIR}.json",
            "file_count": dm["file_count"],
            "total_bytes": dm["total_bytes"],
            "geometry_file": dm["geometry"] is not None,
        })

    comparisons = comparisons_block(EXAMPLES)
    (OUT / "index.json").write_text(
        json.dumps({"runs": sorted(index, key=lambda r: r["name"]),
                    "decks": sorted(decks, key=lambda d: d["run_family"]),
                    "comparisons": comparisons},
                   indent=2, sort_keys=True) + "\n"
   , encoding="utf-8")
    print(f"{len(runs)} run manifests + {len(decks)} deck manifests -> {OUT}")
    n_diff = sum(1 for c in comparisons if c.get("deck"))
    print(f"  {n_diff} family diff decks ")
    print("  wall gate (the wall gate): "
          + ", ".join(f"{n} {v}" for v, n in sorted(wg_counts.items())))
    for r in sorted(index, key=lambda r: r["name"]):
        print(f"  {r['verdict'] or '-':>11}  {r['name']}")
    for d in decks:
        print(f"  {'deck':>11}  {d['run_family']}/{DECK_DIR} "
              f"({d['file_count']} files)")


if __name__ == "__main__":
    sys.exit(main())
