#!/usr/bin/env python3
"""Deployment prerequisite check for the run catalog.

Answers one question before anything else runs here: is this tree, and the
data it describes, present and consistent?  Three levels, each a superset
of the previous:

  browse  (default, <1 s, zero dependencies) — the built outputs that ship
          in this tree are structurally complete and self-consistent:
          index parses, every run manifest exists, every run page exists,
          the switch index and release-history index exist, the switch
          table covers exactly the index's runs, at least one committed
          release-page join exists.

  rebuild (seconds) — the data prerequisite: the sibling SOLPS-ITER
          checkout with its example runs is present, every recorded key
          file exists at its recorded size, and the built outputs are not
          older than the newest input.  Coverage-based by design: ANY
          number of runs is fine — the catalog is discovered from the
          data, so new example runs never fail this check after a rebuild.

  deep   (minutes) — additionally verifies the recorded md5 of every key
          file within the size guard.  A mismatch is reported as
          FOREIGN-INPUTS, not as corruption: it means this tree's outputs
          describe a different (perhaps newer, perhaps modified) copy of
          the run data than the one present — rebuild to re-catalog what
          is actually here.

Exit status: 0 ok, 1 problems found (each with a remediation hint);
--json switches to machine-readable output.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MD5_MAX_BYTES = 200 * 1024 * 1024  # same guard as the manifest builder


def _index_ok(problems: list[str]) -> tuple[list[dict], dict]:
    """Load and minimally validate out/index.json; return its runs."""
    path = HERE / "out" / "index.json"
    try:
        index = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        problems.append("missing built output: out/index.json — this tree "
                        "ships prebuilt; if absent, obtain the full archive")
        return [], {}
    except json.JSONDecodeError as exc:
        problems.append(f"unreadable out/index.json ({exc}) — the built "
                        "outputs are damaged; re-extract the archive")
        return [], {}
    runs = index.get("runs")
    if not isinstance(runs, list) or not runs:
        problems.append("out/index.json carries no runs — the built "
                        "outputs are incomplete; re-extract the archive")
        return [], {}
    return runs, index


def check_browse(problems: list[str]) -> None:
    runs, _ = _index_ok(problems)
    for r in runs:
        man = HERE / "out" / r["manifest"]
        if not man.is_file():
            problems.append(f"missing manifest: out/{r['manifest']}")
            continue
        page = HERE / "out" / "site" / man.stem / "index.html"
        if not page.is_file():
            problems.append(f"missing run page: out/site/{man.stem}/"
                            "index.html")
    for required in ("index.html", "switches/index.html",
                     "deltarun/index.html"):
        if not (HERE / "out" / "site" / required).is_file():
            problems.append(f"missing site page: out/site/{required}")
    sw_path = HERE / "out" / "switchsets.json"
    if sw_path.is_file():
        try:
            sw = json.loads(sw_path.read_text(encoding="utf-8"))
            covered = set(sw.get("runs", {}))
            expected = {r["name"] for r in runs}
            if covered != expected:
                only_index = sorted(expected - covered)[:3]
                only_sw = sorted(covered - expected)[:3]
                problems.append(
                    "switch table and index disagree on runs "
                    f"(index-only: {only_index}, switches-only: {only_sw}) "
                    "— rebuild: ./check_catalog.sh")
        except json.JSONDecodeError as exc:
            problems.append(f"unreadable out/switchsets.json ({exc})")
    else:
        problems.append("missing built output: out/switchsets.json")
    joins = list((HERE / "out" / "deltarun_pages").glob("*.json"))
    if not joins:
        problems.append("no committed release-page join under "
                        "out/deltarun_pages/ — rebuild: ./check_catalog.sh")


def _examples_dir() -> Path:
    """The certified run data: a SOLPS-ITER sibling of the catalog
    tree's workspace.  The tree may sit AT the workspace root (the
    tests' fake trees, the retired standalone repo) or one level
    below it (the folded solps-reader/catalog) — first match wins."""
    for base in (HERE.parent, HERE.parents[1]):
        cand = base / "SOLPS-ITER" / "runs" / "examples"
        if cand.is_dir():
            return cand
    return HERE.parents[1] / "SOLPS-ITER" / "runs" / "examples"


def _interpreter_note(problems: list[str]) -> None:
    """Warn-only: a Python that can import the reader library, for rebuilds."""
    env_py = os.environ.get("CATALOG_PYTHON")
    candidates = [env_py] if env_py else [
        str(HERE.parent / ".venv" / "bin" / "python"),
        str(HERE.parent / "solps-reader" / ".venv" / "bin" / "python")]
    for cand in candidates:
        if not cand:
            continue
        try:
            rc = subprocess.run(
                [cand, "-c", "import solps_reader"],
                capture_output=True, timeout=60).returncode
        except (OSError, subprocess.TimeoutExpired):
            continue
        if rc == 0:
            return
    problems.append("note (non-fatal): no Python with the reader library "
                    "found — browsing needs nothing, but rebuilding does "
                    "(see the package README, The catalog in depth)")


def check_rebuild(problems: list[str]) -> None:
    runs, _ = _index_ok(problems)
    examples = _examples_dir()
    inv = next(
        (b / "askthedocs" / "out" / "switches.json"
         for b in (HERE.parent, HERE.parents[1])), None)
    vendored = HERE / "data" / "askthedocs-switch-inventory.json"
    if not inv.is_file() and not vendored.is_file():
        problems.append(
            "missing prerequisite: switch inventory — neither the "
            "askthedocs sibling's out/switches.json nor the vendored "
            "copy at data/askthedocs-switch-inventory.json is present "
            "(package README, The catalog in depth)")
    if not examples.is_dir():
        problems.append(
            f"missing prerequisite: {examples} — unpack/clone SOLPS-ITER "
            "as a sibling of this tree so its runs/examples holds the "
            "cataloged run families (package README, The catalog in depth)")
        return
    _interpreter_note(problems)
    for r in runs:
        run_dir = examples / r["name"]
        if not run_dir.is_dir():
            problems.append(f"missing run directory: {r['name']} under "
                            f"{examples} (package README, The catalog in depth)")
            continue
        man = json.loads((HERE / "out" / r["manifest"])
                         .read_text(encoding="utf-8"))
        for fname, rec in sorted(man.get("files", {}).items()):
            f = run_dir / fname
            if not f.is_file():
                problems.append(f"{r['name']}: key file {fname} missing")
            elif f.stat().st_size != rec.get("bytes"):
                problems.append(f"{r['name']}: key file {fname} size "
                                f"{f.stat().st_size} != recorded "
                                f"{rec.get('bytes')} — FOREIGN-INPUTS or a "
                                "modified copy; rebuild to re-catalog it")
    index_mtime = (HERE / "out" / "index.json").stat().st_mtime
    for r in runs:
        run_dir = examples / r["name"]
        if not run_dir.is_dir():
            continue
        newest = max((f.stat().st_mtime for f in run_dir.rglob("*")
                      if f.is_file()), default=0.0)
        if newest > index_mtime:
            # mtime alone cannot tell a real input change from a fresh
            # clone of the same content (a sibling tree cloned after
            # the build trips this identically) — a note, not a verdict;
            # the deep level's md5 comparison is the authority
            problems.append(
                f"note stale? inputs of {r['name']} are newer than the "
                "built index — rebuild (./check_catalog.sh) if these are "
                "the files the build read; a freshly cloned identical "
                "tree also trips this, and only the deep md5 check can "
                "tell the two apart")


def check_deep(problems: list[str]) -> None:
    runs, _ = _index_ok(problems)
    examples = _examples_dir()
    if not examples.is_dir():
        problems.append(f"missing prerequisite: {examples}")
        return
    foreign = 0
    for r in runs:
        run_dir = examples / r["name"]
        man_path = HERE / "out" / r["manifest"]
        if not run_dir.is_dir() or not man_path.is_file():
            continue
        man = json.loads(man_path.read_text(encoding="utf-8"))
        for fname, rec in sorted(man.get("files", {}).items()):
            f = run_dir / fname
            want = rec.get("md5")
            if want is None or not f.is_file():
                continue
            if f.stat().st_size > MD5_MAX_BYTES:
                continue
            h = hashlib.md5()
            with open(f, "rb") as fh:
                for chunk in iter(lambda: fh.read(1 << 20), b""):
                    h.update(chunk)
            if h.hexdigest() != want:
                foreign += 1
                problems.append(
                    f"{r['name']}: {fname} md5 differs from the recorded "
                    "value — FOREIGN-INPUTS: this copy is not the one the "
                    "outputs were built from; rebuild to re-catalog what "
                    "is actually here")
    if foreign:
        problems.append(f"deep check: {foreign} file(s) differ from the "
                        "recorded inventory (see FOREIGN-INPUTS notes above)")


LEVELS = ("browse", "rebuild", "deep")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="preflight.py",
        description="Prerequisite check for the run catalog "
                    f"(levels: {' < '.join(LEVELS)}, each a superset)")
    ap.add_argument("--level", choices=LEVELS, default="browse")
    ap.add_argument("--json", action="store_true",
                    help="machine-readable output")
    args = ap.parse_args(argv)

    problems: list[str] = []
    check_browse(problems)
    if args.level in ("rebuild", "deep"):
        check_rebuild(problems)
    if args.level == "deep":
        check_deep(problems)

    fatal = [p for p in problems if not p.startswith("note ")]
    ok = not fatal
    if args.json:
        print(json.dumps({"ok": ok, "level": args.level,
                          "problems": problems}, indent=2))
    else:
        print(f"preflight: {'OK' if ok else 'FAIL'} [level: {args.level}]")
        for p in problems:
            print(f"- {p}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
