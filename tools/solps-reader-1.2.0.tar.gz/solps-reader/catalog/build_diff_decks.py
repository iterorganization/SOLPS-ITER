#!/usr/bin/env python3
"""Family state-diff decks (catalog) — one per comparable family.

For every run family whose canonical pair resolves (rule, pinned
in build_manifests.family_diff_pairs — the same function the manifest
generator uses, so generator and inventory can never disagree on the
pair), generate the A/B comparison deck with SOLPS-Reader's own CLI:

    cli.main(["state", "diff", <A b2fstate>, <B b2fstate>, "-o", outdir])

— the -pinned import path (no parser surgery, no reimplementation
of the deck; that would re-derive, against doctrine).  The deck lands in
figures/<family>__diff/: one overlay+difference PNG per catalog field
(te, ti, ne, na_k..., po — 4 + ns figures) plus diff_summary.txt.

No --b2time-a/b flags: the 2588 pair's A side is ramping_drifts, whose
b2time.nc is the 2.44 GB over-guard file — with the flags omitted the
CLI renders the honest "n/a (--b2time-a not given)" lines and the pure-
python reader never touches it.  Uniform across families, so no guard
branch lives here.  No --geometry either — the measurements and
determinism proofs are on the index-grid form.

Determinism: byte-identical regenerations of ALL deck files (incl.
diff_summary.txt) were verified by cmp during ; the PNGs keep the
matplotlib tEXt chunk (acceptable — decks are staged, hash-pinned
artifacts and stage-1 rebuilds happen in this one venv, FORMATS.md).

Build order: run this BEFORE build_manifests.py — the comparisons block
in index.json inventories the deck; build_catalog.py stages
site/comparisons/<family>/ from that JSON.

Run with the SOLPS-Reader venv interpreter (house rule):
    ../.venv/bin/python build_diff_decks.py [family ...]
"""
from __future__ import annotations

import shutil
import sys
import os
from pathlib import Path

from solps_reader.cli import main as solps_reader_cli

from build_manifests import EXAMPLES, family_diff_pairs

HERE = Path(__file__).resolve().parent
FIGURES = HERE / "figures"


def main(argv: list[str]) -> int:
    os.chdir(HERE)  # relative diff paths resolve from here, any caller cwd
    wanted = set(argv) or None          # None = every family
    n = 0
    for family, pair, n_members, _failures in family_diff_pairs(EXAMPLES):
        if wanted is not None and family not in wanted:
            continue
        if pair is None:
            print(f"skip {family}: {n_members} member(s), no pair passes "
                  "the state-diff precondition")
            continue
        a = EXAMPLES / pair[0] / "b2fstate"
        b = EXAMPLES / pair[1] / "b2fstate"
        out = FIGURES / f"{family}__diff"
        if out.exists():
            shutil.rmtree(out)          # clean deck: no stale fields linger
        print(f"{family}: {pair[0]}  ->  {pair[1]}")
        # portable paths: the summary header embeds both input paths
        # verbatim, so they must be relative to this tree (never
        # machine-absolute)
        rc = solps_reader_cli(["state", "diff",
                               os.path.relpath(a, HERE),
                               os.path.relpath(b, HERE), "-o", str(out)])
        if rc != 0:
            return rc
        n += 1
    print(f"{n} diff decks -> {FIGURES}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
