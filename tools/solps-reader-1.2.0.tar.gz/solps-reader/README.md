# SOLPS-Reader: the run-analysis package for SOLPS-ITER

Readers, CLI, MCP server, and the run catalog: one package, four
faces, one install. It reads the four families of SOLPS-ITER output
files that the B2.5 / EIRENE suite writes, with **numpy + matplotlib
only** (no netCDF4, no scipy, no MATLAB), and it ships the run
catalog: a machine-verifiable provenance-and-quality record over the
public example runs, browsable as a static site that opens with zero
prerequisites.

| Family | Files | Format | Module |
|--------|-------|--------|--------|
| `ft44` | `fort.44` | ASCII: EIRENE → B2.5 source terms | `solps_reader.ft44` |
| `ft46` | `fort.46` | ASCII: EIRENE triangle-mesh tallies | `solps_reader.ft46` |
| `nc` | `b2time.nc`, `b2batch.nc`, any NetCDF-3 sibling | NetCDF-3 classic (binary) | `solps_reader.nc` |
| `state` | `b2fstate` / `b2fstati` (+ `b2fgmtry` geometry) | cf-ASCII (not XDR) | `solps_reader.state`, `solps_reader.gmtry` |

Every parsing rule is taken from the MATLAB reference readers in
`SOLPS-ITER/scripts/MatlabPostProcessing/IO/` and cross-checked
against the Fortran writers. All readers are verified against real
ITER divertor data (case `ITER_2275`, D-only, 20 MW) with byte-level
golden values.

SOLPS-Reader is **read-only, forever**: it never writes or modifies
SOLPS output files.

## Install

Python ≥ 3.10 (developed and frozen on 3.14 / numpy 2.5 / matplotlib
3.11). Install the delivered archive into a virtual environment; no
other prerequisites (numpy, matplotlib, and the MCP runtime install
automatically). One archive, one install: the readers, the CLI, the
MCP server, and the catalog site all work immediately.

```sh
python3 -m venv .venv
.venv/bin/pip install solps-reader-1.2.0.tar.gz
.venv/bin/solps-reader --version     # solps-reader 1.2.0
open catalog/out/site/index.html     # the run catalog (macOS; any browser works)
.venv/bin/solps-mcp                  # the MCP server face (12 tools)
```

The site is static HTML with inline SVG and self-hosted fonts: no
server, no network requests, fully usable offline and with scripts
off.

## The run catalog (the visualizer face)

An independent, machine-verifiable record over the public SOLPS-ITER
example runs (the Zenodo releases): for each cataloged run it records
**which exact code commit produced it**, **whether it actually
converged**, **what its wall and target power loads are**, and
**which solver switches its effective input deck sets**.

Why trust the numbers: every value on every page renders from a JSON
manifest that is itself derived from the run files by a fixed
pipeline; the manifests carry an MD5 inventory of every key input
file; and the rebuild gate (below) proves the whole site rebuilds
**byte-identically** from the same inputs. Nothing on a page is
hand-copied or re-derived.

Open `catalog/out/site/index.html` in any browser (a `file://` URL
works). The site holds four browsable faces:

- **Run dossiers** (9 today): one page per run. Provenance (the
  exact code commit, machine, grid, species), the convergence
  verdict with a per-monitor sparkline strip, wall and target power
  loads (figure when the wall gate passed, the recorded cause
  verbatim otherwise), the run's effective switch table, and the
  key-file inventory.
- **The switch index**: the citation-to-runs direction. All 892
  documented `b2mn.dat` switches, of which these decks set 167 (691
  run entries); every row shows which run sets the switch to what
  value, joined against the documented default (same / differs /
  no default / unknown). The 725 documented-but-never-set switches
  are listed too, with the count arithmetic stated in prose.
- **Family comparisons**: one A/B page per run family. The
  state-diff deck (per-field comparison figures in real R-Z
  geometry with a shared color scale), the diff summary, and the
  family's shared input deck.
- **Release reports**: the release-version axis. Code and analysis
  reports per release pair (what changed between SOLPS-ITER
  versions: the code diff, impact statistics, wall decks), with
  per-case history screens.

Each page carries one
small inline script for client-side table sorting, filtering and
search only; it fetches nothing, and every page stays fully usable
with scripts off. Type is set in three self-hosted font families
(Sora, Source Serif 4, IBM Plex Mono; the OFL license texts ship in
`catalog/fonts/`).

**Viewports.** The site is designed for desktop browsing: a window
roughly 1080 px wide or wider, where the left menu sits beside the
content. Narrower windows stay fully usable: the menu moves behind a
hamburger button at the right end of the header band (opening the
full menu as a panel; closable by the button, a menu choice, the
Escape key, or a click outside; with scripts off the full menu
stacks above the content), and over-wide content (the run table,
dense switch ledgers, long machine identifiers) scrolls or wraps
inside its own box, so the page itself never scrolls sideways at any
width. No phone-specific layout is intended: everything is present
and reachable on a small screen, but the layout does not chase it.

## The MCP face (run analysis over the wire)

`solps-mcp` (or `python -m solps_reader.mcp`) starts a read-only MCP
server with twelve tools for AI-driven run analysis:

- **Run tools**: inventory a run directory; fort.44 field inventory
  and per-field detail; fort.46 summary and per-field detail; solver
  convergence classification from b2time.nc; plasma-state digest
  with quasineutrality check and optional grid cross-check.
- **Changelog**: search the dated doc/LOG changelog and release-note
  titles.
- **Catalog tools**: run-catalog summaries, per-run manifests, and
  the switch joins (a run's effective switch table; which runs set a
  switch), reading the shipped catalog artifacts.

Per-call semantics: every tool takes its run directory, file, or
catalog root as an **explicit argument**; the server never assumes a
location. A call without its path answers a loud named error with an
example call, so a wrong invocation is always self-explaining.

## Quickstart (real ITER_2275 data)

```sh
R=/path/to/unpacked/ITER_2275_Donly_20MW   # any unpacked SOLPS-ITER run tree
PY=.venv/bin/solps-reader

# fort.44: header, species (D, D2, D2+), 182-field statistics table
$PY ft44 summary $R/run_restart/fort.44

# export one field for other tools; plot a quick-look map
$PY ft44 export $R/run_restart/fort.44 --field dab2 -o dab2.npz
$PY ft44 plot    $R/run_restart/fort.44 --field tab2 -o tab2.png \
                --geometry $R/baserun/b2fgmtry    # R-Z field map (optional)

# fort.46: triangle-mesh tallies (8009 triangles, 20 fields)
$PY ft46 summary $R/run_restart/fort.46
$PY ft46 export  $R/run_restart/fort.46 --field pdena -o pdena.npz

# NetCDF-3: solver histories
$PY nc summary $R/run_restart/b2time.nc
$PY nc dump    $R/run_restart/b2time.nc --var timesa -o timesa.npz
$PY nc plot    $R/run_restart/b2time.nc -o convergence.png

# b2fstate: end-of-run plasma state, checked against the geometry file
$PY state summary $R/run_restart/b2fstate
$PY state summary $R/run_restart/b2fstate --check-grid $R/baserun/b2fgmtry

# compare two same-grid states: the A/B deck (restart pair shown)
$PY state diff $R/baserun/b2fstati $R/run_restart/b2fstate -o deck \
                --geometry $R/baserun/b2fgmtry --b2time-b $R/run_restart/b2time.nc
```

The reference SOLPS-ITER tree is read-only input; never modify
anything under it.

## CLI reference

    solps-reader [--version] <family> <command> [options] <file>

| Family | Command | What it prints / writes | Key options |
|--------|---------|--------------------------|-------------|
| `ft44` | `summary` | header (nx, ny, version, git hash), species labels, per-field table (key, size, min, max, mean) | |
| `ft44` | `export` | one field → `.npz` (default) or `.csv` | `--field KEY`*, `-o PATH`, `--format {npz,csv}` |
| `ft44` | `plot` | pcolormesh of one (nx, ny) field: (ix, iy) index grid, or physical R-Z with `--geometry` (per-cell quads from crx/cry corners, equal aspect, guard ring skipped) | `--field KEY`*, `-o PNG`, `--geometry B2FGMTRY` |
| `ft46` | `summary` | header (ntri, version, git hash), species labels, per-field table | |
| `ft46` | `export` | one field → `.npz` (default) or `.csv` | `--field KEY`*, `-o PATH`, `--format {npz,csv}` |
| `nc` | `summary` | dimensions (unlimited dims show record count) + per-variable table (name, dims, dtype, min/max) | |
| `nc` | `dump` | one variable → `.npz` under its own name | `--var NAME`*, `-o PATH` |
| `nc` | `plot` | one stacked panel per 1-D record variable (convergence traces) vs the record dimension | `-o PNG` |
| `state` | `summary` | header (nx, ny, ns, version, git, label), numeric species set, `time`, per-field table | `--check-grid B2FGMTRY` |
| `state` | `diff` | A\|B\|B−A comparison deck for two **same-grid, same-species** states: per-field `<key>.png` (te/ti in eV, per-species `na_k`, shared A/B color scale, symmetric diverging diff; R-Z with `--geometry`) + `diff_summary.txt` (ranges, max\|B−A\|, max per-cell rel) + convergence annotation per side. Refuses (exit 2) on grid or species mismatch | `A B`*, `-o DIR`*, `--geometry B2FGMTRY`, `--b2time-a NC`, `--b2time-b NC` |

\* required. `--field` accepts the **disambiguated keys** shown in the
summary table; on the real file the wall-tally names embed their
stratum (e.g. `wldnek(  1)`). An unknown name exits 2 listing
candidate keys.

**Exit codes:** `0` success (including `--check-grid` PASS) · `1` a
`--check-grid` FAIL (a result, not an error) · `2` unreadable/corrupt
file or usage error (clean message on stderr, no traceback).

`--check-grid` runs three sub-checks: interior dims, derived guard
box (nx+2)×(ny+2), and finite `crx`/`cry` coordinates in the
geometry file; each reported with its own PASS/FAIL line.

## Python API

```python
import numpy as np
from solps_reader.ft44 import read_ft44
from solps_reader.ft46 import read_ft46
from solps_reader.nc import load_nc
from solps_reader.gmtry import read_b2fgmtry
from solps_reader.state import read_b2fstate

ft = read_ft44(".../run_restart/fort.44")     # or read_ft46, read_b2fstate
ft.keys()                                     # disambiguated field keys
dab2 = np.asarray(ft["dab2"].data)            # (90, 36) float64

ncf = load_nc(".../run_restart/b2time.nc")    # dims, variables, attributes
timesa = ncf["timesa"]                        # (1000,) >f8 record variable
ncf.time_traces()                             # 1-D variables vs the record dim

gm = read_b2fgmtry(".../baserun/b2fgmtry")    # 44 cf records, grid_shape (92, 38)
crx = gm["crx"]                               # (92, 38, 4) corner R coordinates
```

## Grid conventions: read this before comparing files

- `fort.44` / `fort.46` report the **interior** grid: nx=90 × ny=36
  (fort.46: 8009 triangles).
- NetCDF (`b2*.nc`), `b2fstate` and `b2fgmtry` carry **guard cells**:
  92 × 38 = (90+2) × (36+2).

Both are correct physics-code behavior; never force them equal. The
interior slice of a 92 × 38 array is `[2:nx+2, 2:ny+2]` (index =
ix+2, iy+2). `state summary --check-grid` automates the cross-file
check.

Units: `b2fstate` stores `te`/`ti` in **joules** (multiply by
6.2415e18 for eV); fort.46 values are raw EIRENE units (the MATLAB
reader's SI factors are *not* applied).

## The catalog in depth: verify, rebuild, extend

Browsing needs nothing. Verifying inputs, rebuilding, or extending
needs the cataloged run data, which is **not** inside this tree:
unpack this package so `catalog/` sits beside a SOLPS-ITER checkout
whose `runs/examples/` holds the cataloged run families (the public
Zenodo release tarballs or the runs Makefile provide them).

**Preflight, three levels** (run from `catalog/`):

```sh
python3 preflight.py                  # seconds: built outputs complete + consistent
python3 preflight.py --level rebuild  # + data sibling present, sizes, freshness
python3 preflight.py --level deep     # minutes: md5 of every recorded key file
```

Each level is a superset of the previous. The check is coverage-based:
it compares the tree's index against whatever data is present, so ANY
number of runs is fine, and new example runs you add and rebuild are
covered too. A size or md5 mismatch reports **FOREIGN-INPUTS**: the
data copy present is not the one these outputs were built from;
rebuild to re-catalog what is actually there. Any failure names the
problem and the fix; nothing fails silently.

**What the outputs are** (all under `catalog/out/`): `index.json`
(the run index: verdicts, machines, grids, code commits; the single
source every page renders from), `manifests/` (one JSON manifest per
run and per family input deck), `switchsets.json` (each run's
effective `b2mn.dat` switch table joined to the documented defaults,
plus the inverted switch-to-runs index), `site/` (the static site),
`deltarun_pages/` (the committed release-report page data), with the
staged figures under `catalog/figures/`.

**Rebuild and the gate.** With a Python that can `import
solps_reader` (the venv above qualifies):

```sh
cd catalog && ../.venv/bin/python -m pytest tests -q   # the suite
./check_catalog.sh                                      # the gate
```

The gate reruns the pipeline (manifests → switch sets → site) and
requires the rebuilt outputs to be **byte-identical** to the ones
shipped here. That proof holds exactly when your `runs/examples`
bytes match the manifests' recorded inventory (`preflight.py --level
deep` verifies that). With different run data the same pipeline
faithfully catalogs YOUR inputs; the per-run code-commit stamps will
then legitimately describe your copy. The switch inventory that
feeds the switch tables ships inside the tree
(`catalog/data/askthedocs-switch-inventory.json`, md5-pinned); if
the askthedocs knowledge-base package sits as a sibling, its live
inventory is preferred (identical bytes either way).

## Documentation

A byte-level format dictionary for all four file families (record
maps, hexdump evidence, golden values, version gates, and every
documented ambiguity) is maintained alongside the code and
**available on request**. The vendored NetCDF-3 reader (`pupynere`,
EUPL-licensed, attribution carried in its source) lives in
`src/solps_reader/_vendor/` with nine numpy-2 / Python-3
compatibility patches applied.

## License

EUPL-1.1, Copyright 2026 Alfonso Sacco (see `LICENSE.md`). The
catalog site bundles OFL-licensed font files; their license texts
travel in `catalog/fonts/`.
