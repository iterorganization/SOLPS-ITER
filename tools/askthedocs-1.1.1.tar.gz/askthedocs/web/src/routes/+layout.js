// adapter-static: prerender EVERY route.  With the adapter's strict mode
// this is the build-time guarantee that web/build/ ships as plain files —
// the whole "no server, no Node at runtime" contract of .
export const prerender = true;
