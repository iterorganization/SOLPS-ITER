# askthedocs: answers in seconds, with citations

A knowledge layer over the SOLPS-ITER documentation corpus. Every
manual, changelog entry, tutorial, reference table, and Fortran
procedure is extracted into **one chunk store** (SQLite + FTS5) with
stable chunk IDs and provenance (source path, section, page), then
served three ways from that single database: a web app, MCP tools
for MCP clients, and a CLI. One engine, one ranking: an answer
looks the same on every face, and every claim carries its citation.

## What you receive

Two artifacts:

1. **This package** is the library, the CLI, the HTTP service with
   the built web client (plus its source), and the MCP face.
2. **`askthedocs-db-1.1.0.tar.gz`** is the pinned data artifact:
   the chunk store plus its build manifest (corpus provenance:
   pinned commit per repository, indexed date, source counts).

## Install

One directory holds both unpacked artifacts and the environment,
and every face resolves from it with zero further configuration:

```sh
mkdir askthedocs-install && cd askthedocs-install   # put both tarballs here
tar xzf askthedocs-1.1.1.tar.gz           # -> askthedocs/    (package + web client)
tar xzf askthedocs-db-1.1.0.tar.gz        # -> askthedocs-db/ (the store)
python3 -m venv .venv                     # Python >= 3.10
.venv/bin/pip install askthedocs-1.1.1.tar.gz
```

**If the reference repositories are cloned on this machine, name
their root before the first launch.** Freshness checking and the
one-click reindex read the local disk, and the icon you are about to
create bakes this value into itself; setting it later means
re-baking the icon:

```sh
export ASKTHEDOCS_REPOS_ROOT="/path/to/dir-holding-the-repos"
```

No cloned repositories? Skip this step; nothing is lost: every leg
is served **carried** from the shipped index, freshness cannot be
checked locally, and the corpus modal says exactly that.

Two closing steps: a quick verify, then the icon:

```sh
.venv/bin/askthedocs search detachment    # optional: proves all faces work
.venv/bin/askthedocs shortcut             # install the icon, once
```

**Click the icon and the corpus opens in your browser.** That click
is the whole everyday gesture from here on; `askthedocs open` is
the same launch from the terminal, icon or not. The icon lands in
your platform's launcher, all user-level, no administrator needed:

| OS | The icon lands | Take it back out |
|---|---|---|
| macOS | a generated `.app` under `~/Applications` | `shortcut --remove` |
| Linux | a `.desktop` entry in `~/.local/share/applications` | `shortcut --remove` |
| Windows | a `.cmd` in the per-user Start Menu | `shortcut --remove` |

**Windows.** Every command in this README applies with the venv's
Scripts directory in place of bin: `.venv\Scripts\askthedocs`
wherever you read `.venv/bin/askthedocs` (`py -3 -m venv .venv`
creates the venv). That one translation rule covers them all.

Three faces share the engine you just verified: the **web
version** the icon opens (the everyday face), the **MCP** tools
for MCP clients (one-time wiring, under "MCP" below), and the
**CLI** for scripts and quick lookups.

The pip install places the Python faces (library, CLI, service,
MCP); the **web client (source and certified build) travels in the
archive tree itself** (`web/` beside this README), so keep the
unpacked archive around and point the service at it as shown under
"Web" below. (The data artifact is independent of the package
version; a newer package runs an older store unchanged, and the
freshness face tells you exactly what you are serving.)

The store is located by a fixed discovery ladder, never by
machine-specific paths:

1. `ASKTHEDOCS_DB` environment variable: explicit override, always
   wins;
2. `./askthedocs-db/askthedocs.db`: beside your launch directory
   (the layout the unpack above creates);
3. `~/.local/share/askthedocs/askthedocs.db`: install once, use
   from anywhere.

When no store is found, every face fails loudly, listing the three
placements with copy-paste fixes. A discovered store is validated
(readable SQLite, the expected schema, FTS5 available in your
Python) with the failure naming the exact problem.

### If it refuses

Every refusal is loud and names its own fix. The three you might
meet on day one:

- **No store found:** the message lists the three accepted
  placements with copy-paste fixes (the ladder above; the
  one-directory install already satisfies step 2).
- **No web client found:** the service still boots and states it
  is API-only; run from the one-directory layout (or set
  `ASKTHEDOCS_STATIC`) and the full app serves.
- **No FTS5 in your Python:** named as such; standard python.org
  installers and mainstream distributions ship it.

Each message states its remedy; following it is the whole
procedure.

## One click: the web version, one gesture away

**The icon opens the web version: the full certified app, not a
reduced launcher view.** The same interface you would get by
starting the service yourself and browsing to it: the search box,
the ranked hits with their citations, the passage pane, the corpus
modal with its freshness chips, everything. The shortcut is not a
second product; it is the web product with its start-up cost
removed.

Why this is the most efficient way for a human to reach the corpus:

- **one gesture, always works:** a click from the Dock, Start
  menu, or launcher; no terminal, no commands, no URL to remember,
  and never a dead bookmark (a URL only works when the server is
  already up; the click *makes* it be up);
- **zero administration at use time:** the icon carries the whole
  context (store, web client, corpus root) baked at creation, and
  starts the service only when none is running;
- **the full research loop, eyes-first:** type, read, open the
  passage, copy the citation; the same engine and the same
  ranking as the CLI and MCP faces, so the answer is identical
  and nothing is lost by choosing the readable one;
- **maintenance lives in the same app:** the freshness chips and
  the reindex button mean even the corpus-care loop needs no
  terminal.

`.venv/bin/askthedocs open` is the whole launcher underneath the
icon: if the service is already up it just opens the app; if not,
it starts the service detached (the same store ladder as
everything else, the log's location printed), waits for it to
answer, and opens the app. Idempotent: run it as often as you
like.

**The shortcut is a snapshot of the moment you create it.** It
bakes three things into the icon: the absolute path of the
installed command, the directory you ran the `shortcut` command
from (the click re-launches there, so the store and web client
beside that directory resolve exactly as your terminal flow does;
a clicked icon would otherwise start at `/` with no environment),
and every `ASKTHEDOCS_*` variable set at creation time (`DB`,
`STATIC`, `REPOS_ROOT`). Move the install, change the launch
directory, or change the variables: re-run the command in the new
context and it overwrites cleanly. The click starts the service
only when none is running (idempotent: a running server is never
restarted, so a server started before you re-baked keeps its old
environment until you stop it).

The web app served by `open` is the certified client when it can
be found: set `ASKTHEDOCS_STATIC`, or unpack the code archive in
the directory you launch from (`./askthedocs/web/build`, the same
layout the install block above creates). Without it the service
boots API-only and `open` says so.

`.venv/bin/askthedocs open --restart` is the explicit convergence
verb for the rare context change: stop a running service and
start a fresh one carrying the current context. It **refuses
while a rebuild is in flight** (nobody restarts into a rebuild on
purpose; the guard catches the accident) and is never needed for
the corpus itself: a rebuild's new store swaps live inside the
running service, so a restart is only ever about environment
variables (`REPOS_ROOT`/`STATIC`/`DB`).

## The three faces

**Web.** The icon (or `askthedocs open`) is the intended way in;
the one-click section above is that story. To start the service
by hand instead: `web/build` is the certified client inside the
unpacked archive (the relative path below assumes you run from
the archive root, `askthedocs/` in the install layout; an
absolute path works from anywhere, as does the `ASKTHEDOCS_STATIC`
environment variable):

```sh
.venv/bin/python -m askthedocs.service --static web/build
# open http://127.0.0.1:8000
```

**MCP** is for MCP clients that speak the Model Context Protocol:

```sh
.venv/bin/askthedocs-mcp
```

Two tools: `search_docs` (corpus search with citations; manual and
Fortran code rank together, so an answer can cite the
documentation AND the implementing procedure) and `get_chunk`
(the full passage behind a hit, before you quote it). The server
introduces itself at session start with a short usage card (also
available as the `how_to_search` prompt in clients that surface
prompts).

**Wiring it into a client.** One rule first: a client-launched
server has no terminal cwd to lean on, so point it at the store
explicitly, with `ASKTHEDOCS_DB` naming the db artifact's
`askthedocs.db` (or install once into the user share, ladder step
3). Then:

*One-line registration:* most MCP-capable coding CLIs ship an
`mcp add` subcommand (user scope, stdio):

```sh
<your-client> mcp add --scope user askthedocs \
  -e ASKTHEDOCS_DB=/full/path/to/askthedocs.db \
  -- /full/path/to/venv/bin/askthedocs-mcp
```

or the same entry as JSON, an `mcpServers` block in the client's
user config, or a project-shared `.mcp.json` at the repo root:

```json
"askthedocs": {
  "type": "stdio",
  "command": "/full/path/to/venv/bin/askthedocs-mcp",
  "env": { "ASKTHEDOCS_DB": "/full/path/to/askthedocs.db" }
}
```

*OpenCode:* in `opencode.json` (project) or
`~/.config/opencode/opencode.json`:

```json
{
  "mcp": {
    "askthedocs": {
      "type": "local",
      "command": ["/full/path/to/venv/bin/askthedocs-mcp"],
      "environment": { "ASKTHEDOCS_DB": "/full/path/to/askthedocs.db" },
      "enabled": true
    }
  }
}
```

(`python -m askthedocs.mcp` is the same face if you prefer it to
the console script.) Wire it once; every session after starts
with the usage card and both tools live.

**CLI**

```sh
.venv/bin/askthedocs search "limiter configurations"   # ranked hits, phrase-tier marked
.venv/bin/askthedocs search b2mndr_stim                # exact switch name ranks first
.venv/bin/askthedocs show <chunk_id>                   # full passage + provenance
.venv/bin/askthedocs status                            # corpus drifted since the build?
```

Query syntax: plain terms (implicit AND), quoted phrases. Power
users may type raw FTS5 query syntax; a query that parses as
valid FTS5 takes that meaning (e.g. `column:term` filters);
anything unparseable falls back to plain-term search rather than
erroring.

**The chunk id is the deep link.** Every hit (CLI, web, MCP)
carries a 40-character chunk id naming exactly one passage. Find
a result anywhere, then fetch it by id alone, with no re-search:
the web pane's copy buttons put the id (or a full citation line,
or a restoring deep link) on your clipboard; over MCP the same
loop is `search_docs` → `get_chunk(<id>)`. Worked example:

```sh
.venv/bin/askthedocs search "feedback schemes"
#   hit: SOLPS-Tutorials/docs/feature_blog/Gas_puffing_and_pumping.md,
#        section 'Density feedback schemes'
#        chunk ec9ff6572b5dc079bee027db8e9a13311eee061e
.venv/bin/askthedocs show ec9ff6572b5dc079bee027db8e9a13311eee061e
#   the exact passage, verbatim, with its provenance
```

One paste, one call: the intended way to hand a citation to an
assistant and have it read the source without re-discovering it.
(Identities are stable: ids are hashes of provenance and survive
corpus rebuilds, so a citation stays fetchable.)

## What is in the index

**48,921 chunks from 158 sources** (build manifest pin below):
the SOLPS-ITER manuals (TeX) and text-rich PDFs, the EIRENE
manual, the GUI's reST documentation, the DivGeo HTML manual, the
dated doc/LOG changelog (since 2006), the SOLPS-Tutorials and
course material, the ADAS data references, the **b2mn.dat switch
inventory** (all 892 switches, synthesized from the B2.5 source
census and the documented defaults), and the **B2.5 + EIRENE
Fortran source indexed as procedure units**: every Fortran file,
with main programs deliberately out; they are orchestration over
procedures that are all indexed, and their identifiers are
covered elsewhere in the corpus. The GUI enters through its
documentation; no switch or subroutine joins in its code.

The db self-describes: the build manifest beside it records each
repository's pinned commit; the web landing shows this
provenance, per module, with links; `askthedocs status` re-hashes
the corpus and reports current or drifted.

## Determinism

The chunk store is **byte-reproducible**: the same corpus state
always rebuilds to a byte-identical database. The web client is a
built-once **certified artifact**: `web/BUILD-CERT.txt` records
its tree digest and the exact toolchain. Rebuilding the client
yourself (optional) requires Node >= 18 with the committed
lockfile (`npm ci && npm run build:api` in `web/`, after clearing
`web/.svelte-kit` and `web/node_modules/.vite`) and may differ in
bytes from the certified build; the digest tells them apart.

## Performance

The search path carries a measured budget: `/search` p95 <= 50 ms
(localhost, warm, steady-state; not a cold-start claim). The
harness is committed and rerunnable: `tools/perf.py` measures
p50/p95/p99, stamps its artifact, and exits non-zero over budget.
Off localhost or under load, latencies stretch with the network
and the machine; the budget is the local reference point, not a
warranty for remote deployments.

## Rebuilding the corpus (optional)

The shipped store is the recommended way to run askthedocs. To
build your own index over a local checkout of the repositories
instead:

```sh
.venv/bin/askthedocs corpus    # scan the repos (see --iter/--gui paths)
.venv/bin/askthedocs build     # ~4 min; writes the store + manifest
```

Works on Linux, macOS, and Windows (pure Python; your Python's
SQLite must include FTS5, which standard python.org installers
and mainstream distributions provide). The build-side commands
(`corpus`, `build`, `status`) assume a **checkout of this
repository** as the working layout: from a bare pip install they
have no repos to scan and say so loudly; the read faces
(search/show/service/MCP) work everywhere via the discovery
ladder.

### Freshness and the carried rebuild

`askthedocs status` (and the corpus modal's freshness band on the
web face) reports every repository and module **leg** as one of:

- **current:** on disk, matches the index;
- **drifted:** on disk, differs (the file-level evidence is
  printed: new, changed, removed);
- **carried:** not on disk; served verbatim from the index at the
  pinned commit the row shows.

The check reads the local disk only; it never queries a remote
repository, and it never needs one: a fresh install with **zero
clones** searches the complete shipped corpus, with every leg
carried.

A rebuild needs only the legs you care about. With, say, a fresh
SOLPS-ITER checkout but no Tutorials/SOLPS-GUI clones:

```sh
.venv/bin/askthedocs corpus    # carries the absent legs, loudly named
.venv/bin/askthedocs build     # fresh extraction of what's on disk;
                               # absent legs carried at their pinned
                               # commits: byte-for-byte the store a
                               # full checkout at those states builds
```

Under a leg that IS on disk, the disk is the truth: deletions
propagate (they show as drift first, never vanish silently), and
nothing carries. A leg that is neither on disk nor recorded in
the current store refuses the build by name: clone it, or install
the matching index artifact. Cloning every repository once and
updating only the ones you use remains an equally valid workflow:
presence always makes a leg freshly extractable and its freshness
checkable.

The web face exposes the same machinery: the corpus modal
re-checks freshness on every open, and when an on-disk leg has
drifted it offers the rebuild behind an evidence-carrying
confirmation (carried legs named, the measured duration of the
last rebuild quoted). The rebuild goes to a temporary store and
swaps in only on success; search keeps answering from the current
index throughout. `POST /reindex` is the service's first
write-capable endpoint: this is a deliberately local,
unauthenticated service, so do not expose it beyond your machine.

## License

EUPL-1.1, Copyright 2026 Alfonso Sacco; see `LICENSE.md`. The web
client bundles OFL-licensed fonts and MIT-licensed Svelte runtime
code; their notices travel in `web/THIRD-PARTY-NOTICES.md`. Deep
format documentation (chunk schemas, the ranking tiers, the
recovery card rules) is available on request.
