"""askthedocs — searchable knowledge layer over the SOLPS-ITER corpus.

One chunk store, many faces: the CLI, the solps-mcp tools, and the static
web app all query the same SQLite FTS5 database.
"""

__version__ = "1.1.1"
