Widget OpenValidateDlg(View w);
