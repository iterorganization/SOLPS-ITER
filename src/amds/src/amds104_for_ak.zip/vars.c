#include <string.h>
#include <stdlib.h>
#include "vars.h"

Vars CreateVars() {
  Vars v;

  v=Malloc(sizeof(*v));
  v->count=v->dataLen=0;
  v->data=NULL;

  return v;
}

void* FreeVars(Vars v) {
  if (v->data!=NULL) Free(v->data);
  Free(v);

  return NULL;
}

void SetVar(Vars v,char* name,char* value) {
  size_t p,oldLen,newLen;

  if (value==NULL) value="";

  for (p=0;p<v->dataLen;) {
    if (!strcmp(v->data+p,name)) {
      p+=strlen(v->data+p)+1;
      goto found;
    }
    p+=strlen(v->data+p)+1;
    p+=strlen(v->data+p)+1;
  }
  v->data=Realloc(v->data,v->dataLen+=strlen(name)+strlen(value)+2);
  strcpy(v->data+p,name);
  strcpy(v->data+p+strlen(name)+1,value);

  return;

  found:
  oldLen=strlen(v->data+p);
  newLen=strlen(value);

  if (newLen>oldLen) v->data=Realloc(v->data,v->dataLen+=newLen-oldLen);

  memmove(v->data+p+newLen+1,v->data+p+oldLen+1,
    v->dataLen-p-oldLen-1);
  strcpy(v->data+p,value);
}

char* GetVar2(Vars v,char* name,char* defVal) {
  size_t p;

  for (p=0;p<v->dataLen;) {
    if (!strcmp(v->data+p,name)) return v->data+p+strlen(name)+1;
    p+=strlen(v->data+p)+1;
    p+=strlen(v->data+p)+1;
  }
  return defVal;
}

void CopyVars(Vars src,Vars dest) {
  Free(dest->data);
  dest->count=src->count;
  dest->dataLen=src->dataLen;
  dest->data=Malloc(dest->dataLen);
  memmove(dest->data,src->data,dest->dataLen);
}
